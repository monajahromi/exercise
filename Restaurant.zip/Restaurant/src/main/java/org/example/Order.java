package org.example;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Order {

    private int orderID;
    private Customer customer;
    private List<OrderItems> orderItems;
    private LocalDateTime createdAt;

    public Order(int orderID, Customer customer, List<OrderItems> orderItems) {
        this.orderID = orderID;
        this.customer = customer;
        this.orderItems = orderItems;
        this.createdAt = LocalDateTime.now();
    }

    public Order(int orderID, Customer customer) {
        this.orderID = orderID;
        this.customer = customer;
        this.createdAt = LocalDateTime.now();
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<OrderItems> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItems> orderItems) {
        this.orderItems = orderItems;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public void addOrderItem(Food food, int num) {
        if (orderItems == null) {
            orderItems = new ArrayList<>();
        }
        orderItems.add(new OrderItems(food, num));
    }

    public int sumPrice(){
        int sum=0;
        for (OrderItems orderItem : orderItems) {
            sum+=orderItem.getFood().getPrice();
        }
        return sum;
    }
}