package org.example;

public class OrderItems {

    private Food food;


    private int num;

    public OrderItems(Food food, int num) {
        this.food = food;
        this.num = num;
    }

    public Food getFood() {
        return food;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

}
