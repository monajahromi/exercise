package org.example;

abstract public class prsn {

    private int id;

    private String name;

    private String lastName;

    private int password;

    public prsn(int id, String name, String lasteName, int password) {
        this.id = id;
        this.name = name;
        this.lastName = lasteName;
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }
}
