package org.example;

public class Admin extends prsn {
    public Admin(int id, String name, String lastName, int password) {
        super(id, name, lastName, password);
    }


}

