package org.example;

import org.example.Admin;
import org.example.Customer;
import org.example.Order;

import java.util.ArrayList;
import java.util.List;

public class Database {

    public  List<Admin> adminList;
    public  List<Customer> customerList;
    public  List<Order> orderList ;

    private List<Food>foodList;

    public Database() {
        this.adminList =new ArrayList<>();
        this.customerList =new ArrayList<>();
        this.orderList =new ArrayList<>();
        this.foodList=new ArrayList<>();
    }

    public void initializeFood(){
        foodList=new ArrayList<>();
        foodList.add(new Food());
    }

    public List<Admin> getAdminList() {
        return adminList;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public List<Order> getOrderList() {
        return orderList;
    }

    public List<Food> getFoodList() {
        return foodList;
    }
}