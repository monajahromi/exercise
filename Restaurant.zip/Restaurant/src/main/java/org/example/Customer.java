package org.example;

public class Customer extends prsn{

    public Customer() {
        super(id, name, lastName, password);
    }

}
