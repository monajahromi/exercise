package org.example;

public enum FoodCategory {
    FOOD,DRINK;
}
