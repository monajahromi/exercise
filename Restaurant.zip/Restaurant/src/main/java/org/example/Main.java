package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Database database=new Database();
        Customer customer = new Customer();
        //login
        Customer currentCustomer=null;
        //Menu
        Order order =new Order(1,currentCustomer);

        for (Food food : database.getFoodList()) {
            if(food.getId()==2){
                order.addOrderItem(food,5);
                break;
            }
        }


    }
}